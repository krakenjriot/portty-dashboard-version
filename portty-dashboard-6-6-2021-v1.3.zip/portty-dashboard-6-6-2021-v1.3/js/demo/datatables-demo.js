$(document).ready(function() {
  //$('#dataTable').DataTable();
  $('table.display').DataTable();
})

